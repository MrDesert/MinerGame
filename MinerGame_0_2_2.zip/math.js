function mathTriangularNumber(N){
    return N * (N+1)/2;
}
